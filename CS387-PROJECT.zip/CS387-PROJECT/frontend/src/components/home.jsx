import React, { Fragment } from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import "./home.css";
import { useParams } from "react-router-dom";
import Navbar from "./nav";




export default function Home() {
  //const { date, from, to } = useParams();
  const [single_s, setsingle_s] = useState([]);
  const [multi_s, setmulti_s] = useState([]);
  const [merge_s, setmerge_s] = useState([]);
  const [to_loc_new, setto_loc_new] = useState('');
  const [from_loc_new, setfrom_loc_new] = useState('');
  const [date_new, setdate_new] = useState('');
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const result = axios.post("http://localhost:5000/select", {date:date_new, from_loc:from_loc_new, to_loc:to_loc_new}, { withCredentials: true });
      window.location.href = "/home";
    } catch (err) {
      console.log(err);
    }
  }
  const handlesingle = (sid) => {
    try {
      window.location.href = "/book_single/" + sid;
    }
    catch (err) {
      console.log(err);
    }
  }
  const handlemulti = (sid1, sid2) => {
    try {
      window.location.href = "/book_multi/" + sid1 + "/" + sid2;
    }
    catch (err) {
      console.log(err);
    }
  }
  const handlemerge = (sid1, sid2) => {
    try {
      window.location.href = "/book_merge/" + sid1 + "/" + sid2;
    }
    catch (err) {
      console.log(err);
    }
  }







  
  useEffect(() => {
    axios.get('http://localhost:5000/home', { withCredentials: true })
      .then(res => {

        setsingle_s(res.data.single);
        setmulti_s(res.data.multi);
        setmerge_s(res.data.merge);
        setdate_new(res.data.date);
        setfrom_loc_new(res.data.from);
        setto_loc_new(res.data.to);
        console.log(res.data);


      })
      .catch(err => {
        if (err.response.status === 401) {
        }
      })
  }, [])







  return (
    <Fragment>
      <Navbar />

      <form
        onSubmit={handleSubmit}
        style={{
          display: 'box',
          height: '60px',
          flexDirection: 'row',
          gap: '16px',
          padding: '16px',
        }}
      >
        <div>
          <label htmlFor="date">Date:</label>
          <input
            type="date"
            id="date"
            value={date_new}
            onChange={(event) => setdate_new(event.target.value)}
          />
        </div>
        <div>
          <label htmlFor="arrival">Arrival:</label>
          <input
            type="text"
            id="arrival"
            value={from_loc_new}
            onChange={(event) => setfrom_loc_new(event.target.value)}
          />
        </div>
        <div>
          <label htmlFor="departure">Departure:</label>
          <input
            type="text"
            id="departure"
            value={to_loc_new}
            onChange={(event) => setto_loc_new(event.target.value)}
          />
        </div>
        <button type="submit">Submit</button>
      </form>
      <h2  >single</h2>
      <table>
        <thead>
          <tr>
            <th>company</th>
            <th>sid</th>
            <th>from_loc</th>
            <th>from_time</th>
            <th>to_time</th>
            <th>to_loc</th>
            <th>available</th>
            <th>price</th>
            <th>book</th>
          </tr>
        </thead>
        <tbody>
          {single_s.map((item) => (
            <tr key={item.sid}>
              <td>{item.company}</td>
              <td>{item.sid}</td>
              <td>{item.from_loc}</td>
              <td>{item.from_time.toString().slice(11, 16)}</td>
              <td>{item.to_time.toString().slice(11, 16)}</td>
              <td>{item.to_loc}</td>
              <td>{item.capacity - item.filled}</td>
              <td>{item.price}</td>
              <td><button type='submit' onClick={() => handlesingle(item.sid)}>book</button></td>
            </tr>
          ))}
        </tbody>
      </table>
      <h2 >multi</h2>
      <table>
        <thead>
          <tr>
            <th>company</th>
            <th>sid1</th>
            <th>sid2</th>
            <th>from_loc</th>
            <th>from_time</th>
            <th>mid_time_a</th>
            <th>mid_loc</th>
            <th>mid_time_b</th>
            <th>to_time</th>
            <th>to_loc</th>
            <th>available</th>
            <th>price</th>
            <th>book</th>
          </tr>
        </thead>
        <tbody>
          {multi_s.map((item) => (
            <tr>
              <td>{item.company}</td>
              <td>{item.sid1}</td>
              <td>{item.sid2}</td>
              <td>{item.from_loc}</td>
              <td>{item.from_time.toString().slice(11, 16)}</td>
              <td>{item.mid_time_a.toString().slice(11, 16)}</td>
              <td>{item.mid_loc}</td>
              <td>{item.mid_time_b.toString().slice(11, 16)}</td>
              <td>{item.to_time.toString().slice(11, 16)}</td>
              <td>{item.to_loc}</td>
              <td>{Math.min(item.aval1, item.aval2)}</td>
              <td>{item.price}</td>
              <td><button type='submit' onClick={() => handlemulti(item.sid1, item.sid2)}>book</button></td>

            </tr>
          ))}
        </tbody>
      </table>
      <h2 >merge</h2>
      <table>
        <thead>
          <tr>
            <th>company</th>
            <th>sid</th>
            <th>from_loc</th>
            <th>from_time</th>
            <th>to_time</th>
            <th>to_loc</th>
            <th>available</th>
            <th>price</th>
            <th>company</th>
            <th>sid</th>
            <th>from_loc</th>
            <th>from_time</th>
            <th>to_time</th>
            <th>to_loc</th>
            <th>available</th>
            <th>price</th>
            <th>book</th>
          </tr>
        </thead>
        <tbody>
          {merge_s.map((item) => (
            <tr>
              <td>{item.company1}</td>
              <td>{item.sid1}</td>
              <td>{item.from_loc1}</td>
              <td>{item.from_time1.toString().slice(11, 16)}</td>
              <td>{item.to_time1.toString().slice(11, 16)}</td>
              <td>{item.to_loc1}</td>
              <td>{item.aval1}</td>
              <td>{item.price1}</td>
              <td>{item.company2}</td>
              <td>{item.sid2}</td>
              <td>{item.from_loc2}</td>
              <td>{item.from_time2.toString().slice(11, 16)}</td>
              <td>{item.to_time2.toString().slice(11, 16)}</td>
              <td>{item.to_loc2}</td>
              <td>{item.aval2}</td>
              <td>{item.price2}</td>
              <td><button type='submit' onClick={() => handlemerge(item.sid1, item.sid2)}>book</button></td>

            </tr>
          ))}
        </tbody>



      </table>


    </Fragment>
  );
}











