import React, { useState } from "react";
import axios from "axios";

import "./login.css";


const Login = () => {

  
  const [date, setDate] = useState("");
  const [arrival, setArrival] = useState("");
  const [departure, setDeparture] = useState("");
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/select", {
        date,
        from_loc:arrival,
        to_loc:departure,
      }, { withCredentials: true });
      if (response.status === 200) {
        window.location.href = "/home";
      }
    } catch (e) {
      console.log(e);
    }
  };



  return (
    //form with date and arrivalstring and departure string
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="date">Date:</label>
        <input
          type="date"
          id="date"
          value={date}
          onChange={(event) => setDate(event.target.value)}
        />


      </div>
      <div>
        <label htmlFor="arrival">Arrival:</label>
        <input
          type="text"
          id="arrival"
          value={arrival}
          onChange={(event) => setArrival(event.target.value)}
        />
      </div>
      <div>
        <label htmlFor="departure">Departure:</label>
        <input
          type="text"
          id="departure"
          value={departure}
          onChange={(event) => setDeparture(event.target.value)}
        />
      </div>

      <button type="submit">Submit</button>


    </form>
  );
};

export default Login;
