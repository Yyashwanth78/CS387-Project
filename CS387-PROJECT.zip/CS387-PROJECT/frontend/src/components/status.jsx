import axios from 'axios';
import React, { Fragment, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Navbar from './nav';
import './home.css';



export default function Status() {
    const [user_info , setuser_info] = useState([]);
    const [single , setsingle] = useState([]);
    const [multi , setmulti] = useState([]);


    useEffect(() => {
        axios.get('http://localhost:5000/status', { withCredentials: true })
            .then(res => {
                setsingle(res.data.single);
                setmulti(res.data.multi);
                setuser_info(res.data.user_info);

            }
            )
            .catch(err => console.log(err));
    }

    , []);

    return (
        <Fragment>
            <Navbar />
            <h1>status</h1>

            <h2>user_info</h2>
            <p>
                {user_info.map((item) => (
                    <p>
                        {item.user_id}
                        {item.name}
                        {item.mobile_no}
                    
                    </p>
                ))}

            </p>

            <h2>single</h2>
            <table>
                <thead>
                    <tr>
                        <th>date</th>
                        <th>company</th>
                        <th>sid</th>
                        <th>from_loc</th>
                        <th>from_time</th>
                        <th>to_time</th>
                        <th>to_loc</th>
                        <th>seats</th>
                        <th>price</th>

                    </tr>

                </thead>
                <tbody>
                    {single.map((item) => (
                        <tr>
                            <td>{item.from_time.toString().slice(0,10)}</td>
                            <td>{item.company}</td>
                            <td>{item.sid}</td>
                            <td>{item.from_loc}</td>
                            <td>{item.from_time.toString().slice(11,16)}</td>
                            <td>{item.to_time.toString().slice(11,16)}</td>
                            <td>{item.to_loc}</td>
                            <td>{item.seats}</td>
                            <td>{item.price}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <h2>multi</h2>
            <table>
                <thead>
                    <tr>
                        <th>date</th>
                        <th>company</th>
                        <th>sid1</th>
                        <th>sid2</th>
                        <th>from_loc</th>
                        <th>from_time</th>
                        <th>mid_time_a</th>
                        <th>via</th>
                        <th>mid_time_b</th>
                        <th>to_time</th>
                        <th>to_loc</th>
                        <th>seats</th>
                        <th>price</th>
                    </tr>
                </thead>
                <tbody>
                    {multi.map((item) => (
                        <tr>
                            <td>{item.from_time.toString().slice(0,10)}</td>
                            <td>{item.company}</td>
                            <td>{item.sid1}</td>
                            <td>{item.sid2}</td>
                            <td>{item.from_loc}</td>
                            <td>{item.from_time.toString().slice(11,16)}</td>
                            <td>{item.mid_time_a.toString().slice(11,16)}</td>
                            <td>{item.via}</td>
                            <td>{item.mid_time_b.toString().slice(11,16)}</td>
                            <td>{item.to_time.toString().slice(11,16)}</td>
                            <td>{item.to_loc}</td>
                            <td>{item.seats}</td>
                            <td>{item.price}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </Fragment>
    )
}





