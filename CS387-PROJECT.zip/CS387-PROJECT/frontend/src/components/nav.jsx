import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import "./nav.css"; // import the navbar styles
import axios from "axios";
import { useState } from "react";


function Navbar() {
  const handlelogout = () => {
    //logout the user
    try {
      const result = axios.get("http://localhost:5000/logout", { withCredentials: true });
      window.location.href = "/login";
    }
    catch (err) {
      console.log(err);
    }
  }
  async function handlehome  ()  {
    //redirect to home
    try {
      window.location.href = "/home";
    }
    catch (err) {
      console.log(err);
    }
  }




  return (
    //shows the user_info and home and status and logout
    <nav className="navbar">
      <div>
        
      </div>
      <div className="navbar-container">
        
        <ul className="nav-menu">
          <li className="nav-item">
            <Link  onClick={handlehome}>
              Home
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/status">
              Status
            </Link>
          </li>
          <li className="nav-item">
            <Link onClick={handlelogout}>
              Logout
            </Link>

          </li>
        </ul>
      </div>
    </nav>


  );
}

export default Navbar;
