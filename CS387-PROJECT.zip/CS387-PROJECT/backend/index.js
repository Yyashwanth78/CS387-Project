const express = require('express');
const app = express();
const cors = require('cors');
const pool = require('./db');
const session = require("express-session");
const bcrypt = require('bcrypt');

app.use(cors(
  {
    origin: "http://localhost:3000",
    credentials: true
  }

));
app.use(express.json());


app.use(session({
  secret: "abcd",
  resave: true,
  saveUninitialized: true,

}));
const checkLoggedIn = (req, res, next) => {
  if (!req.session.user) {
    res.status(401).send("Unauthorized");
  } else {
    next();
  }
};


app.post("/login", async (req, res) => {
  // Replace this with your actual authentication logic
  const { username, password } = req.body;
  console.log(username, password);
  const result = await pool.query(
    'select password from user_password where user_id = $1', [username]
  );
  console.log(username, password)

  if (result.rows.length > 0) {
    if (await bcrypt.compare(password , result.rows[0].password)) {
      req.session.user = username;
      console.log("username ", req.session.user)
      res.status(200).send({ username });
    } else {
      res.status(401).send("Unauthorized");
    }
  }
});


app.post("/clogin", async (req, res) => {
  // Replace this with your actual authentication logic
  const { username, password } = req.body;
  console.log(username, password);
  const result = await pool.query(
    'select password from company_auth where company = $1', [username]
  );

  if (result.rows.length > 0) {
    if (await bcrypt.compare(password ,result.rows[0].password)) {
      req.session.user = username;
      res.status(200).send({ username });
    } else {
      res.status(401).send("Unauthorized");z
    }
  }
});


app.post("/select", async (req, res) => {
  console.log(req.body);
  const { date, from_loc, to_loc } = req.body;
  req.session.date = date;
  req.session.from_loc = from_loc;
  req.session.to_loc = to_loc;
  console.log(req.session.date, req.session.from_loc, req.session.to_loc);

  res.status(200).send({ date, from_loc, to_loc });
});



app.get('/home', async (req, res) => {
  try {
    console.log('HOME');

    const date = req.session.date;
    const from = req.session.from_loc;
    const to = req.session.to_loc;
    const result = await pool.query('SELECT * FROM single WHERE from_time::date = $1 and from_loc = $2 and to_loc = $3 order by price', [date, from, to]);
    const multi = await pool.query('with a as (select * from single where from_time::date = $1 and (from_loc = $2 or to_loc = $3)) select a.company,a.sid as sid1 ,b.sid as sid2, a.from_loc as from_loc, a.from_time as from_time , a.to_loc as mid_loc, a.to_time as mid_time_a,b.from_time as mid_time_b, b.to_loc as to_loc,b.to_time as to_time,a.capacity-a.filled as aval1 , b.capacity-b.filled as aval2,multi.price  from (a join  a as b on a.to_loc=b.from_loc),multi where a.to_loc = b.from_loc and a.to_time<b.from_time and multi.sid1=a.sid and multi.sid2=b.sid order by price', [date, from, to]);
    const merge = await pool.query('with a as (select * from single where from_time::date = $1 and from_loc = $2) , b as (select * from single where from_time::date = $1 and to_loc = $3) select a.company as company1 , a.sid as sid1, a.from_loc as from_loc1,a.from_time as from_time1, a.to_loc as to_loc1 , a.to_time as to_time1, a.price as price1 , a.capacity-a.filled as aval1 , b.company as company2 , b.sid as sid2, b.from_loc as from_loc2,b.from_time as from_time2, b.to_loc as to_loc2 , b.to_time as to_time2, b.price as price2 , b.capacity-b.filled as aval2 from a,b where a.to_loc=b.from_loc and a.to_time<b.from_time order by (a.price + b.price)', [date, from, to]);

    res.json({ date, from, to, single: result.rows, multi: multi.rows, merge: merge.rows });

  
  }
  catch (err) {
    console.error(err.message);
  }
});



app.get('/chome/:date', async (req, res) => {
  try {
    const { date } = req.params;
    const company = req.session.user;
    const single_s = await pool.query('SELECT * FROM single WHERE from_time::date = $1 and company = $2 order by price', [date, company]);
    const multi_s = await pool.query('with a as (select * from single where from_time::date= $1 and company =$2)  select sid1,sid2,a.from_loc as from_loc, a.from_time as from_time,a.to_loc as mid_loc,a.to_time as mid_time_a,b.from_time as mid_time_b,b.to_loc as to_loc ,b.to_time as to_time, multi.price as price,a.capacity-a.filled as aval1 , b.capacity-b.filled as aval2 from (multi join a on multi.sid1=a.sid) join a as b on multi.sid2=b.sid order by price', [date, company]);
    const merge_s = await pool.query('with a as (select * from single where from_time::date = $1 and company = $2)   select a.sid as sid1 ,b.sid as sid2, a.from_loc as from_loc , a.from_time as from_time , a.to_loc as mid_loc, a.to_time as mid_time_a,b.from_time as mid_time_b, b.to_loc as to_loc,b.to_time as to_time from a, a b where a.to_loc = b.from_loc and a.to_time<b.from_time and not exists(select * from multi where sid1=a.sid and sid2=b.sid ) ', [date, company]);
    res.json({ company: company, single_s: single_s.rows, multi_s: multi_s.rows, merge_s: merge_s.rows });

  }
  catch (err) {
    console.error(err.message);
  }
});

app.get('/merge/:sid1/:sid2', async (req, res) => {
  try {
    const { sid1, sid2 } = req.params;
    const company = req.session.user;
    const result = await pool.query('select * from single where (sid = $1 or sid = $2) and company = $3 order by price', [sid1, sid2, company]);
    console.log("jasjdhfjsdf");
    res.json(result.rows);
  }
  catch (err) {
    console.error(err.message);
  }
});


app.post('/merges/:sid1/:sid2/:newprice', async (req, res) => {
  try {
    const { sid1, sid2, newprice } = req.params;
    //need to insert into multi table
    const result = await pool.query('insert into multi values($1,$2,$3)', [sid1, sid2, newprice]);
    res.json(result.rows);
  }
  catch (err) {
    console.error(err.message);
  }
});


app.get('/remove_multi/:sid1/:sid2', async (req, res) => {
  try {
    const { sid1, sid2 } = req.params;
    const company = req.session.user;
    const result = await pool.query('with a as (select * from multi where sid1=$1 and sid2=$2) select sid1,sid2,b.from_loc as from_loc , b.from_time as from_time , b.to_loc as mid_loc, b.to_time as mid_time_a,c.from_time as mid_time_b, c.to_loc as to_loc,c.to_time as to_time,a.price as price,b.capacity-b.filled as aval1 ,c.capacity-c.filled as aval2 from a join single as b on a.sid1=b.sid join single as c on a.sid2=c.sid where b.company = $3 and c.company = $3 order by price', [sid1, sid2, company]);
    console.log("jasjdhfjsdf");
    res.json(result.rows);
  }
  catch (err) {
    console.error(err.message);
  }
});

app.post('/remove_multis/:sid1/:sid2', async (req, res) => {
  try {
    const { sid1, sid2 } = req.params;
    const result = await pool.query('delete from multi where sid1 = $1 and sid2 = $2', [sid1, sid2]);
    res.json(result.rows);
  }
  catch (err) {
    console.error(err.message);
  }
});

app.get('/remove_single/:sid', async (req, res) => {
  try {
    const { sid } = req.params;
    const company = req.session.user;
    const single = await pool.query('select * from single where sid = $1 and company = $2', [sid, company]);
    const multi = await pool.query('with a as (select * from multi where sid1 =$1 or sid2 =$1) select sid1,sid2,b.from_loc as from_loc, b.from_time as from_time, b.to_loc as mid_loc, b.to_time as mid_time_a,c.from_time as mid_time_b,c.to_loc as to_loc ,c.to_time as to_time,a.price as price,b.capacity - b.filled as aval1 ,c.capacity-c.filled as aval2 from (a join single as b on a.sid1=b.sid) join single as c on a.sid2=c.sid where b.company =$2 and c.company =$2 order by price', [sid, company]);
    res.json({ single: single.rows, multi: multi.rows });
  }
  catch (err) {
    console.error(err.message);
  }
});


app.post('/remove_singles/:sid', async (req, res) => {
  try {
    const { sid } = req.params;

    const result = await pool.query('delete from single where sid = $1', [sid]);
    const result1 = await pool.query('delete from multi where sid1 = $1 or sid2 = $1', [sid]);
    res.json({ result: result.rows, result1: result1.rows });
  }
  catch (err) {
    console.error(err.message);
  }
});


app.get('/book_single/:sid', async (req, res) => {
  try {

    const { sid } = req.params;
    console.log(req.session.user);
    const result = await pool.query('select * from single where sid = $1', [sid]);
    res.json(result.rows);
  }
  catch (err) {
    console.error(err.message);
  }
});

app.get('/book_singles/:sid/:seats', async (req, res) => {
  try {
    const { sid, seats } = req.params;
    console.log(req.session.user);
    console.log(sid, seats);

    if (seats > 0) {
      const result = await pool.query('update single set filled = filled+$2 where sid = $1', [sid, seats]);
      const result1 = await pool.query('insert into user_single values($1,$2,$3) on conflict (user_id,sid) do update set seats = user_single.seats+$3', [req.session.user, sid, seats]);

      res.json(result.rows);
    }
  }
  catch (err) {
    console.error(err.message);
  }
});

app.get('/book_multi/:sid1/:sid2', async (req, res) => {
  try {
    const { sid1, sid2 } = req.params;
    console.log(sid1, sid2);

    const result = await pool.query('with a as (select * from single where sid = $1), b as (select * from single where sid = $2), c as (select * from multi where sid1 = $1 and sid2 = $2) select a.company,sid1 ,sid2, a.from_loc as from_loc , a.from_time as from_time , a.to_loc as mid_loc, a.to_time as mid_time_a,b.from_time as mid_time_b, b.to_loc as to_loc,b.to_time as to_time, a.capacity-a.filled as aval1,b.capacity-b.filled as aval2    ,c.price as price from a,b,c order by price', [sid1, sid2]);
    res.json(result.rows);

  }
  catch (err) {
    console.error(err.message);
  }
});

app.get('/book_multis/:sid1/:sid2/:seats', async (req, res) => {
  try {
    const { sid1, sid2, seats } = req.params;
    const user_id = req.session.user;

    console.log(user_id, sid1, sid2, seats);
    if (seats > 0) {
      const result = await pool.query('update single set filled = filled+$3 where sid = $1 or sid = $2', [sid1, sid2, seats]);
      const result1 = await pool.query('insert into user_multi values($1,$2,$3,$4) on conflict (user_id,sid1,sid2) do update set seats = user_multi.seats+$4', [user_id, sid1, sid2, seats]);
      res.json(result.rows);
    }
  }
  catch (err) {
    console.error(err.message);
  }
});


app.get ('/book_merge/:sid1/:sid2',async (req,res)=>{
  try{
    const {sid1,sid2} = req.params;
    console.log(sid1,sid2);
    const result = await pool.query('select * from single where sid = $1 or sid = $2',[sid1,sid2]);
    res.json(result.rows);
  }
  catch(err){
    console.error(err.message);
  }
}
);



app.get('/book_merges/:sid1/:sid2/:seats',async (req,res)=>{
  try{
    const {sid1,sid2,seats} = req.params;
    console.log(sid1,sid2,seats);
    const result = await pool.query('update single set filled = filled+$3 where sid = $1 or sid = $2',[sid1,sid2,seats]);
    const result1 = await pool.query('insert into user_single values($1,$2,$3) on conflict (user_id,sid) do update set seats = user_single.seats+$3',[req.session.user,sid1,seats]);
    const result2 = await pool.query('insert into user_single values($1,$2,$3) on conflict (user_id,sid) do update set seats = user_single.seats+$3',[req.session.user,sid2,seats]);
    res.json(result.rows);
  }

  catch(err){
    console.error(err.message);
  }
}
);







app.get('/status', async (req, res) => {
  try {
    const user_id = req.session.user;

    console.log(user_id);
    const user_info = await pool.query('select * from user_info where user_id = $1 ', [user_id]);
    const single = await pool.query('select single.company,single.sid,from_loc,from_time,to_loc,to_time,seats,price from user_single,single where user_id = $1 and user_single.sid = single.sid order by from_time', [user_id]);
    const multi = await pool.query('with a as (select * from user_multi where user_id=$1),b as (select multi.sid1,multi.sid2,multi.price,a.seats from multi,a where a.sid1=multi.sid1 and a.sid2=multi.sid2) select c.company,b.sid1,b.sid2,c.from_loc as from_loc , c.from_time as from_time , c.to_time as mid_time_a, c.to_loc as via, d.from_time as mid_time_b, d.to_loc as to_loc, d.to_time as to_time,seats,b.price from b,single as c , single as d where b.sid1=c.sid and b.sid2=d.sid order by from_time', [user_id]);

    res.json({ user_info: user_info.rows, single: single.rows, multi: multi.rows });
  }
  catch (err) {
    console.error(err.message);
  }
});



















app.get('logout', async (req, res) => {
  req.session.destroy();
  res.status(200);
  console.log('Logged out');

});

app.get('/clogout', async (req, res) => {
  req.session.destroy();
  res.status(200);
  console.log('Logged out')
});








app.listen(5000, () => {
  console.log('Server is running on port 5000');
});